import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-DcnuH5gM.js";import"./index-DFKgMh2M.js";export{m as default};
