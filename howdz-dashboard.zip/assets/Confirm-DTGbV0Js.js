import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-CZbDXXdb.js";import"./index-D2TQ7GJw.js";export{m as default};
