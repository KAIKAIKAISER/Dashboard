import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-Dx-_oAF9.js";import"./index-CUbD2Ola.js";export{m as default};
