import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-Cmdin6km.js";import"./index-B9UfMzaS.js";export{m as default};
