import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-CNZZz2SK.js";import"./index-Tl4U071d.js";export{m as default};
