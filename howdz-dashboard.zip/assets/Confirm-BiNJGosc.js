import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-CDjCMGvh.js";import"./index-BvXEPoT_.js";export{m as default};
