const t=""+new URL("video-thumb-BVtyHYeM.png",import.meta.url).href;export{t as _};
