import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-CHb5XVhh.js";import"./index-HlQwGPLk.js";export{m as default};
