import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-BiS8nZO8.js";import"./index-ETMCZV73.js";export{m as default};
