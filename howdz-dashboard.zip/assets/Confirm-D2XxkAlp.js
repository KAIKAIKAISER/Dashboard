import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-CWGiVwi-.js";import"./index-BVDSnG85.js";export{m as default};
