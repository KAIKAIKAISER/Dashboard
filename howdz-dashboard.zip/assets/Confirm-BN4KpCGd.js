import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-hoeuGwCr.js";import"./index-NmtvmwJK.js";export{m as default};
