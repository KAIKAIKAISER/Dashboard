import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-C2ktdb_P.js";import"./index-Bmdgl8ps.js";export{m as default};
