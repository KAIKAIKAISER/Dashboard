import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-DTOxEUSC.js";import"./index-CZvTCXuw.js";export{m as default};
