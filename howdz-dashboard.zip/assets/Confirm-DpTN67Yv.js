import{_ as m}from"./Confirm.vue_vue_type_script_setup_true_lang-Bx8Lmp-q.js";import"./index-q1mMpWhm.js";export{m as default};
